const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
    projectId: Number,
    taskId:Number,
    parentId:Number,
    taskName:String,
    startDate:String,
    endDate:String,
    priority:Number,
    status:String,
    employeeId:Number,
    parent: {
        parentId: Number,
        parentTask: String
    },
    isParent: Boolean
    });

const Task = mongoose.model('tasks', taskSchema);

module.exports = Task;
