const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
    projectId: Number,
    projectName: String,
    startDate: Date,
    endDate: Date,
    priority:Number,
    employeeId:Number,
    selectDate:Boolean
    });

const Project = mongoose.model('projects', projectSchema);

module.exports = Project;
