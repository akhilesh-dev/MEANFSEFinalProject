const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bodyParser = require('body-parser');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended: true}));

router.get('/', (req, res) => {
    User.find({}, (err, docs) => {
        if(err) console.log('Error: ', err)
        else{
            console.log(docs);
            res.json(docs);
        }
    });
});

router.post('/create', (req, res) => {
    createUser(req, res);
});

router.put('/update/:id', (req, res) => {
    updateUser(req, res);
});

router.delete('/remove/:id', (req, res)=>{
    
    removeUser(req, res);
});


async function createUser(request, response){
    const user = new User(request.body);
    var userCount = await User.count({});
    
    console.log(userCount);
    user.userId = userCount + 1;
    console.log(user    );
    await user.save()
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));  
}

async function updateUser(request, response){
    const data = request.body;
    console.log(data);
    console.log(request.params.id);
   await  User.updateOne({userId: request.params.id},{
        $set:
        {
            'userId': data.userId, 
            'firstName': data.firstName,
            'lastName': data.lastName,
            'employeeId': data.employeeId
        }
    })
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));     
}

async function removeUser(request, response){
    const uId = request.params.id;
    console.log(uId);
    const user = await User.deleteOne({userId: uId});
    console.log(user);
    response.send(user);
    
}

module.exports = router;