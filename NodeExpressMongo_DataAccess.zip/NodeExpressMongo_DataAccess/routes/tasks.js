const express = require('express');
const router = express.Router();
const Task = require('../models/task');
const bodyParser = require('body-parser');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended: true}));

router.get('/:id', (req, res) => {
    console.log(req.params.id);
    Task.find({"projectId" : req.params.id}, (err, docs) => {
        if(err) console.log('Error: ', err)
        else{
            console.log(docs);
            res.json(docs);
        }
    });
});

router.post('/create', (req, res) => {
    createTask(req, res);
});

router.put('/update/:id', (req, res) => {
    updateTask(req, res);
});

router.put('/end/:id', (req, res)=>{    
    endTask(req, res);
});

async function createTask(request, response){
    const task = new Task(request.body);
    var taskCount = await Task.count({});    
    console.log(taskCount);
    task.taskId = taskCount + 1;    
    console.log(task.parentId);
    console.log(task);
    await task.save()
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));  
}

async function updateTask(request, response){
    const data = request.body;
    console.log(data);
   await  Task.updateOne({taskId: data.taskId},{
        $set:
        {             
            'parentId': data.parentId,
            'taskName': data.taskName,
            'startDate': data.startDate,
            'endDate': data.endDate,
            'priority': data.priority,
            'status': data.status,
            'employeeId': data.employeeId,
            'parent': data.parent,
            'isParent': data.isParent
        }
    })
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));     
}

async function endTask(request, response){
    const tId = request.params.id;
    console.log(tId);
    await  Task.updateOne({taskId: tId},{
        $set:
        {   
            'status': request.body.status
        }
    })
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));        
}

module.exports = router;