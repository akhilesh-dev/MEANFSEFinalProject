const express = require('express');
const router = express.Router();
const Project = require('../models/project');
const bodyParser = require('body-parser');
router.use(bodyParser.json());

router.get('/', (req, res) => {
    Project.find({}, (err, docs) => {
        if(err) console.log('Error: ', err)
        else{
            res.json(docs);
        }
    });
});

router.post('/create', (req, res) => {
    createProject(req, res);
});

router.put('/update/:id', (req, res) => {
    updateProject(req, res);
});

router.delete('/remove/:id', (req, res)=>{
    
    removeProject(req, res);
});

async function createProject(request, response){
    const project = new Project(request.body);
    var projectCount = await Project.count({});
    
    console.log(projectCount);
    project.projectId = projectCount;
    await project.save()
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));  
}

async function updateProject(request, response){
    const data = request.body;
    console.log(data);
    console.log(request.params.id);
   await  Project.updateOne({projectId: request.params.id},{
        $set:
        {
            'projectName': data.projectName, 
            'startDate': data.startDate,
            'endDate': data.endDate,
            'selectDate': data.selectDate,
            'employeeId': data.employeeId,
            'priority': data.priority
        }
    })
    .then(result => response.send(result))
    .catch(err => response.status(400).send('Unable to save data.'));  

}

async function removeProject(request, response){
    const projId = request.params.id;
    console.log(projId);
    const project = await Project.deleteOne({projectId: projId});
    console.log(project);
    response.send(project);
    
}

module.exports = router;