const express = require('express');
const app = express();
const projects = require('./routes/projects');
const users = require('./routes/users');
const tasks = require('./routes/tasks');
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test')
.then(() => console.log('Connected to MongoDB...'))
.catch(err => console.log('Could not connect to MongoDB...', err));


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE');
    next();
  });

app.use('/api/projects', projects);
app.use('/api/users', users);
app.use('/api/tasks', tasks);

app.get('/', (req, res) => {
    res.send('Hello');
});

app.listen(3000, () => console.log('listening on port 3000...'));